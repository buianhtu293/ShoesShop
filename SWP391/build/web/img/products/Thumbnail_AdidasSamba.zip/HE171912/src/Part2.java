
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class Part2 {

    public static void main(String[] args) {
        float num1, num2;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input the number 1: ");
        num1 = scanner.nextFloat();
        System.out.println("Input the number 2: ");
        num2 = scanner.nextFloat();
        System.out.println("Input the operator(+-*/): ");
        String op1= scanner.nextLine();
        String op = scanner.nextLine();
        switch (op) {
            case "+":
                System.out.println(num1 + "+" + num2 + "=" + (num1 + num2));
                break;
            case "-":
                System.out.println(num1 + "-" + num2 + "=" + (num1 - num2));
                break;
            case "*":
                System.out.println(num1 + "*" + num2 + "=" + (num1 * num2));
                break;
            case "/":
                System.out.println(num1 + "/" + num2 + "=" + (num1 / num2));
                break;
            default:
                System.out.println("Out of system");
        }
    }
}
