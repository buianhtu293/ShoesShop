
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class Part3 {

    public static void main(String[] args) {
        System.out.println("Input number of student: ");
        Scanner scanner = new Scanner(System.in);
        int n;
        n = scanner.nextInt();
        scanner.nextLine();
        String[] list = new String[n];
        for (int i = 0; i < n; i++) {
            list[i] = scanner.nextLine();
        }
        System.out.println("List: ");
        for (int i = 0; i < n; i++) {
            System.out.println(list[i]);
        }
        System.out.println("List after upper: ");
        for (int i = 0; i < n; i++) {
            String[] word = list[i].split(" ");
            String list1 = "";
            for (String w : word) {
                list1 = list1 + (w.substring(0, 1).toUpperCase() + w.substring(1));
                list1 = list1 + " ";
            }
            System.out.println(list1);
        }
        for (int i = 0; i < n; i++) {
            list[i].toUpperCase();
        }
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                if (list[i].compareTo(list[j]) > 0) {
                    String temp = list[i];
                    list[i] = list[j];
                    list[j] = temp;
                }
            }
        }
        for (int i = 0; i < n; i++) {
            list[i].toLowerCase();
        }
        for (int i = 0; i < n; i++) {
            String[] word = list[i].split(" ");
            String list1 = "";
            for (String w : word) {
                list1 = list1 + (w.substring(0, 1).toUpperCase() + w.substring(1));
                list1 = list1 + " ";
            }
            System.out.println(list1);
        }
    }
}
