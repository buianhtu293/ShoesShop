
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Admin
 */
public class Part1 {

    public static void main(String[] args) {
        int rows;
        int cols;
        int matrix[][];
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of rows:");
        rows = scanner.nextInt();
        System.out.println("Enter number of cols:");
        cols = scanner.nextInt();
        System.out.println("Enter the matrix:");
        matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.println("m" + "[" + i + "]" + "[" + j + "]" + "=");
                matrix[i][j] = scanner.nextInt();
            }
        }
        System.out.println("Matrix Inputted:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.format("%3d", matrix[i][j]);
            }
            System.out.println("\n");
        }
        int sum = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                sum = sum + matrix[i][j];
            }
        }
        System.out.println("Sum:" + sum);
        double avg = 0;
        avg = (double) sum / (rows * cols);
        System.out.println("Average: " + avg);
        System.out.println("Sort: ");
        for (int a = 0; a < rows; a++) {
            for (int i = 0; i < cols - 1; i++) {
                for (int j = i + 1; j < cols; j++) {
                    if (matrix[a][i] < matrix[a][j]) {
                        int temp = matrix[a][i];
                        matrix[a][i] = matrix[a][j];
                        matrix[a][j] = temp;
                    }
                }
            }
            for (int b = 0; b < cols; b++) {
                System.out.format("%3d", matrix[a][b]);
            }
            System.out.println("\n");
        }
    }
}
